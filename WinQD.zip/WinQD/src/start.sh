#!/usr/bin/env bash
set -Eeuo pipefail

# You can override this hook to execute a script before startup!

return 0
